public class GUIStart {
    public static void main(String[] args) {
        Login.main(args);
    }
}
